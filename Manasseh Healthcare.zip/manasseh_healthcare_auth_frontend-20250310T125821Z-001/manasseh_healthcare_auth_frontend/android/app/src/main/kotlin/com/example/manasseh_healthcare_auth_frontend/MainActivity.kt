package com.example.manasseh_healthcare_auth_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
